import type { Media, Slide } from './types';

/**
 * Everything personal lives in this file: copy, dates, which photo goes where.
 * Files are in /public/assets. The browser uses the first format it can play.
 */
export const AUDIO_SOURCES = ['/assets/track.m4a', '/assets/track.mp3'] as const;

const photo = (n: number, alt: string, focus?: string): Media => ({
  kind: 'image',
  src: `/assets/media/photo-${String(n).padStart(2, '0')}.jpg`,
  alt,
  focus,
});

const clip = (n: number, alt: string, focus?: string): Media => ({
  kind: 'video',
  src: `/assets/media/clip-${String(n).padStart(2, '0')}.mp4`,
  poster: `/assets/media/clip-${String(n).padStart(2, '0')}-poster.jpg`,
  alt,
  focus,
});

export const SLIDES: Slide[] = [
  // 1. Cover
  {
    id: 'cover',
    type: 'cover',
    durationMs: 7000,
    media: photo(8, 'Dola in pink and violet light, pouting at the camera', '50% 30%'),
    masthead: 'Friendship Wrapped, 2026 edition',
    titleLines: ['Dola,', 'wrapped.'],
    dek: 'Best friends, officially since May 9. Unofficially, longer.',
    soundHint: 'Tap anywhere to experience with sound.',
  },

  // 2. Mileage
  {
    id: 'mileage',
    type: 'mileage',
    durationMs: 7000,
    label: 'Friendship mileage',
    startDate: '2026-05-09',
    unit: 'days, officially.',
    footnote:
      'Counting from May 9, 2026. The unofficial count started earlier and neither of us is doing that math.',
    receipt: [
      { label: 'Reply speed', value: 'suspiciously fast' },
      { label: 'Texts she turns into calls', value: 'all of them' },
      { label: 'Times she has said “meudddddd”', value: 'unauditable' },
    ],
  },

  // 3. Archetype + chaos meter
  {
    id: 'archetype',
    type: 'archetype',
    durationMs: 8000,
    titleLines: ['The', 'Caring', 'Menace'],
    tagline: 'Looks harmless. Is not.',
    exhibit: photo(10, 'Dola in a grey tee looking down, calm and innocent', '50% 25%'),
    exhibitCaption: 'Exhibit A: allegedly harmless',
    meterTitle: 'Chaos meter',
    meters: [
      {
        label: 'Caring',
        value: 100,
        note: 'Maxed out. I keep having to raise the ceiling.',
        tone: 'warm',
      },
      {
        label: 'Reply speed',
        value: 97,
        note: 'Answers before I have finished typing.',
        tone: 'warm',
      },
      {
        label: 'Would rather call than text',
        value: 100,
        note: 'Send “hi.” Your phone rings.',
        tone: 'chaos',
      },
      {
        label: 'Low-key evil',
        value: 78,
        note: 'The “low-key” is doing a lot of work.',
        tone: 'chaos',
      },
      {
        label: 'Crazy',
        value: 92,
        note: 'You nor get sense. We love it.',
        tone: 'chaos',
      },
    ],
  },

  // 4. Reel. 8s split evenly across the items, so 6 items is ~1.3s each.
  {
    id: 'reel',
    type: 'reel',
    durationMs: 8000,
    items: [
      {
        media: photo(2, 'Dola in a red Reebok tee giving a thumbs-up, braids down', '50% 35%'),
        caption: '“I finally got ittttt!!!” Same energy, always.',
        captionAt: 'top',
      },
      {
        media: clip(1, 'Dola in round glasses with braids down, at home'),
        caption: 'Four eyes does it best. Her words.',
        captionAt: 'top',
      },
      {
        media: photo(3, 'A four-panel selfie of Dola saying goodbye to her braids'),
        caption: 'Farewell, braids. The mourning was dramatic.',
        captionAt: 'bottom',
      },
      {
        media: photo(9, 'Dola in a sheet mask making a peace sign', '50% 40%'),
        caption: 'Sheet mask. Peace sign. Low-key evil.',
        captionAt: 'bottom',
      },
      {
        media: clip(2, 'Dola with her natural hair up, in a graphic tee'),
        caption: 'Natural does it best. Still her words.',
        captionAt: 'top',
      },
      {
        media: photo(7, 'Dola in red light, pouting with a peace sign', '50% 35%'),
        caption: 'Glowing. Also plotting.',
        captionAt: 'bottom',
      },
    ],
  },

  // 5. Award
  {
    id: 'award',
    type: 'award',
    durationMs: 7500,
    media: photo(4, 'Dola in a floral shirt with a Superwoman sticker', '50% 30%'),
    sealText: 'the golden meudddddd • the golden meudddddd • ',
    title: 'Most Caring Menace',
    presentedTo: 'Presented to Dolabomi. Nobody else was considered.',
    citations: [
      'Replying before I have finished typing.',
      'Calling when a text would have done.',
      'Being low-key evil and the kindest person in the room at the same time.',
    ],
    footer: 'Panel of judges: one, me. Appeals: denied, mumu.',
  },

  // 6. Letter + finale
  {
    id: 'letter',
    type: 'letter',
    durationMs: 8000,
    backdrop: photo(11, 'Dola in a Bobina tee with her hand on her head, in soft daylight', '50% 30%'),
    heading: 'Happy birthday, Dola.',
    paragraphs: [
      'Officially best friends since May 9th. But we both know it started way before that. The date is just when it became official.',
      'You reply before I finish typing. You call when a text would do. You are funny, low-key evil, a little crazy, and the first one to show up when it counts. I would not change a thing.',
      'I hope this year is as good to you as you are to everyone else. Love you, mumu. Meudddddd.',
    ],
    signoff: 'Adenike',
    replayLabel: 'Play it again',
  },
];
